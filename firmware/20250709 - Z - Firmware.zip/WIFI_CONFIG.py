SSID = 'Guest-Finvit93'
PASSWORD = 'fIN_01121@!!'

# Hotspot tramite telefono cellulare
# Disattivare WiFi prima di attivare l'hotspot, in questo modo compare la scelta della banda 2.4/5.0GHz
# SSID = 'Marce_RNote_10S'
# PASSWORD = 'Kawa.500'
