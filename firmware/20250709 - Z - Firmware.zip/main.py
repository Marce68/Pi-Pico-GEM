from machine import Pin, PWM, UART, Timer
import time
import CRC16modbus as mb
import bluetooth
from BLEXpress_Peripheral import BLESimplePeripheral

# OTA Update modules
from ota import OTAUpdater
from WIFI_CONFIG import SSID, PASSWORD


# PIN definition and settings ##################################################################
BUILTIN_LED = Pin('LED', Pin.OUT)
START = Pin('GPIO15', Pin.IN)
POS_SW = Pin('GPIO11',Pin.IN)

C_TEC_POW = Pin('GPIO21',Pin.OUT)

LED_R = PWM(Pin('GPIO14'))
LED_G = PWM(Pin('GPIO13'))
LED_B = PWM(Pin('GPIO12'))
LED_R.freq(1000)
LED_G.freq(1000)
LED_B.freq(1000)
R, G, B, blink = (0, 0, 0, False)
LED_ON = False

C_BUZ = PWM(Pin('GPIO7'))
C_BUZ.freq(4000)

C_MOT = PWM(Pin('GPIO2'))
C_MOT.freq(20000)

C_PUMP_FAN = PWM(Pin('GPIO8'))
C_PUMP_FAN.freq(20000)

I_MOT = machine.ADC(26) # ADC0
T_CAV = machine.ADC(27) # ADC1
V_MOT = machine.ADC(28) # ADC2
T_MCU = machine.ADC(4) # Internal temperature sensor
MAX_SAMPLES = 30
I_MOT_BUFF = []
T_CAV_BUFF = []
V_MOT_BUFF = []
T_MCU_BUFF = []


# Debug UART #################################################################################
debug = UART(0, baudrate=9600, tx=Pin('GPIO0'), rx=Pin('GPIO1'))
debug.init(bits=8, parity=None, stop=1)

# Variabili globali ##########################################################################
dbg_str = ""
start_pulse = 0 # Cattura impulso dalla scheda di interfaccia
pulse_duration = 0 # Durata impulso dalla scheda di interfaccia 
selector = [0, 0] # Ultime due posizioni del selettore
cycle_duration = 0 # Durata del ciclo corrente
start_cycle = 0 # Cattura istante di avvio del ciclo corrente
actual_time = 0 # Tempo effettivo del ciclo corrente

# cycle management
std_cycle_duration = [60,120,180,240,300,360,420,480] # durata del ciclo in secondi in base al valore di selector
extra_time = False
option = 0 # Deafult is "Cream", can be set to 0x01, which is "Solid"
ext_cycle_duration = [120,180]

# SYSTEM_STATUS
# 0x00 == 0 == Blocked
# 0x01 == 1 == Ready for Production
# 0x02 == 2 == Production (std time)
# 0x12 == 18 == Production (ext time)
# 0x03 == 3 == Production finished (std time)
# 0x13 == 19 == Production finished (ext time)
# 0x04 == 4 == Production interrupted
# 0x05 == 5 == Error
# 0xFF == 255 == Idle
status = {
    'Idle' : 0xFF,
    'Blocked' : 0x00,
    'Ready' : 0x01,
    'Run_std' : 0x02,
    'Run_ext' : 0x18,
    'End_std' : 0x03,
    'End_ext' : 0x19,
    'Pause' : 0x04,
    'Error' : 0x05
}
current_status = status['Idle']
old_status = None
num_pause = 0

# Function and Callbacks ##########################################################################
def dumpData ():
    global current_status, selector
    
    dbg_str = str('{x:6d}'.format(x=current_status) +
    '\t\t{x:5.2f}'.format(x=sum(I_MOT_BUFF)/MAX_SAMPLES) +
    '\t\t{x:5.2f}'.format(x=sum(T_CAV_BUFF)/MAX_SAMPLES) +
    '\t\t{x:5.2f}'.format(x=sum(V_MOT_BUFF)/MAX_SAMPLES) +
    '\t\t{x:5.2f}'.format(x=sum(T_MCU_BUFF)/MAX_SAMPLES) +              
    '\t\t{x:6d}'.format(x=POS_SW.value()) +
    '\t\t{x:6d}'.format(x=selector[-1]) + '\n\r')
    
    print(dbg_str, end ='\r')
    debug.write(dbg_str)

def stateMachine (ev):
    global current_status, old_status, num_pause, cycle_duration, start_cycle, actual_time

    if ev == 1: # Singola pressione del tasto START
        if current_status == status['Idle']:
            current_status = status['Ready']
        elif current_status == status['Blocked']:
            current_status = status['Ready']
        elif current_status == status['Ready']:
            start_cycle = time.ticks_ms()
            current_status = status['Run_std']
            num_pause = 0
        elif current_status == status['Run_std']:
            num_pause +=1
            if num_pause < 2:
                actual_time += time.ticks_diff(time.ticks_ms(), start_cycle)
                old_status = current_status
                current_status = status['Pause']
            else:
                current_status = status['End_std']
        elif current_status == status['Run_ext']:
            num_pause +=1
            if num_pause < 2:
                actual_time += time.ticks_diff(time.ticks_ms(), start_cycle)
                old_status = current_status
                current_status = status['Pause']
            else:
                current_status = status['end_ext']
        elif current_status == status['End_std']:
            current_status = status['Idle']
        elif current_status == status['End_ext']:
            current_status = status['Idle']
        elif current_status == status['Pause']:
            start_cycle = time.ticks_ms()
            current_status = old_status
        elif current_status == status['Error']:
            # Error handling
            pass
        else:
            current_status = 0xAA
        # dumpData()
    elif ev == 2: # cambio di stato per uscita da stand_by
        current_status = status['Idle']
        pass
    elif ev == 3: # cambio di stato per sollevamento braccio motore
        if current_status == status['Run_std'] or current_status == status['Run_ext']:
            num_pause +=1
            if num_pause < 2:
                actual_time += time.ticks_diff(time.ticks_ms(), start_cycle)
                old_status = current_status
                current_status = status['Pause']
            elif current_status == status['Run_std']:
                current_status = status['end_std']
            elif current_status == status['Run_ext']:
                current_status = status['end_ext']
    elif ev == 4: # cambio di stato per abbssamento braccio motore
        if current_status == status['Pause']:
            start_cycle = time.ticks_ms()
            current_status = old_status
    elif ev == 5: # cambio di stato per evento ambientale (temperature anomale) / BLE / WiFi
        pass
    elif ev == 6: # warning o errore
        pass

# NON FUNZIONA CORRETTAMENTE: IN ALCUNI CASI VIENE LETTO PER DUE VOLTE DI SEGUITO UN VALORE ERRATO
# SELETTORE SU 2 VIENE LETTO 1 O 3 o 6 E ANCHE, MA MOLTO RARAMENTE, UN AVVIO CICLO
def START_irq_handler(pin):
    global start_pulse, pulse_duration, selector, cycle_duration, stand_by
        
    if pin.value() == 0:
        # Fronte di discesa: inizio impulso, start_time must be global
        start_pulse = time.ticks_us()
    else:
        # Fronte di salita: fine impulso, pulse_duration must be global
        pulse_duration = time.ticks_diff(time.ticks_us(), start_pulse)
        # print("Durata impulso:", pulse_duration, "us")
        
        # Selector position
        if pulse_duration > 1500 and pulse_duration < 2000:
            selector.append(1)
            selector.pop(0)
            cycle_duration = 60000
        elif pulse_duration > 3500 and pulse_duration < 4000:
            selector.append(2)
            selector.pop(0)
            cycle_duration = 120000
        elif pulse_duration > 5500 and pulse_duration < 6000:
            selector.append(3)
            selector.pop(0)
            cycle_duration = 180000
        elif pulse_duration > 7500 and pulse_duration < 8000:
            selector.append(4)
            selector.pop(0)
            cycle_duration = 240000
        elif pulse_duration > 9500 and pulse_duration < 10000:
            selector.append(5)
            selector.pop(0)
            cycle_duration = 300000
        elif pulse_duration > 11500 and pulse_duration < 12000:
            selector.append(6)
            selector.pop(0)
            cycle_duration = 360000
        elif pulse_duration > 13500 and pulse_duration < 14000:
            selector.append(7)
            selector.pop(0)
            cycle_duration = 420000
        elif pulse_duration > 15500 and pulse_duration < 16000:
            selector.append(8)
            selector.pop(0)
            cycle_duration = 480000

        if selector[0] != selector[1] and stand_by:
            stand_by = False
            print("Durata impulso:", pulse_duration, "us")
            stateMachine (2) # Elaborare l'evento "uscita stand by"

        # Start pressed ?
        if pulse_duration > 2900 and pulse_duration < 3000:
            if stand_by:
                stand_by = False
                stateMachine (2)
            else:
                # per il long-press memorizzare in un buffer i valori consecutivi e nel ciclo principale elaborare
                stateMachine (1) # Elaborare l'evento "pressione tasto"
                
           
def POS_SW_irq_handler (pin):
    global stand_by, current_status, R, G, B, blink

    if pin.value() == 1: # Braccio motore alzato
        if stand_by: 
            stand_by = False
            stateMachine (2) # Uscita dallo stand_by
        else:
            C_MOT.duty_u16(int(0 * 65535 / 255)) # Motore OFF
            stateMachine (3) # Gestione Macchina in Pausa
    else:
        # stateMachine (4) # Gestione Uscita dalla Pausa
        pass

def adcGetSamples (timer):
    I_MOT_BUFF.append((I_MOT.read_u16()-324)/10.142)
    T_CAV_BUFF.append(8.5-(T_CAV.read_u16()-44200)/775)
    V_MOT_BUFF.append((V_MOT.read_u16()-330)/3498)
    T_MCU_BUFF.append(27-(T_MCU.read_u16()*(3.3/65536)-0.706)/0.001721)

    if len (I_MOT_BUFF) > MAX_SAMPLES:
        I_MOT_BUFF.pop(0)
        T_CAV_BUFF.pop(0)
        V_MOT_BUFF.pop(0)
        T_MCU_BUFF.pop(0)


# def setColor(R, G, B):
#     global R, G, B
#     # Set the duty cycle for each color channel
#     LED_R.duty_u16(int(R * 65535 / 255))
#     LED_G.duty_u16(int(G * 65535 / 255))
#     LED_B.duty_u16(int(B * 65535 / 255))

def toggle_led(timer):
    global LED_ON
    
    LED_ON = not LED_ON
    if blink:
        sw = LED_ON
    else:
        sw = 1
    BUILTIN_LED.value(sw)
    LED_R.duty_u16(int(sw * R * 65535 / 255))
    LED_G.duty_u16(int(sw * G * 65535 / 255))
    LED_B.duty_u16(int(sw * B * 65535 / 255))
    dumpData()
    
def runCycle ():
    global cycle_duration, actual_time, current_status
    
    # Gestisce la fine del ciclo
    if actual_time >= cycle_duration:
        if current_status == status['Run_std']:
            current_status = status['End_std']
            # C_BUZ.duty_u16(int(255 * 65535 / 255))
        elif current_status == status['Run_ext']:
            current_status = status['End_ext']
        else:
            pass
    else:    
        C_PUMP_FAN.duty_u16(int(255 * 65535 / 255))
        C_MOT.duty_u16(int(128 * 65535 / 255)) # sostituire con chiamata che gestisce il profilo motore
        C_TEC_POW.value(1)
        
def standByCycle ():
    global R, G, B, blink 
    # Spegnere tutto
    (R, G, B, blink) = (0, 0, 0, False)
    C_PUMP_FAN.duty_u16(int(0 * 65535 / 255))
    C_MOT.duty_u16(int(0 * 65535 / 255))
    C_TEC_POW.value(0) 

# Interrupts
START.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=START_irq_handler)
POS_SW.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=POS_SW_irq_handler)

# Timers
blink_timer = Timer()
blink_timer.init(mode=Timer.PERIODIC, period=500, callback=toggle_led)

adc_timer = Timer()
adc_timer.init(mode=Timer.PERIODIC, period=100, callback=adcGetSamples)

# Bluetooth communication ########################################################### BEGIN
ble = bluetooth.BLE() # Crea una istanza dell'oggetto BLE
p = BLESimplePeripheral(ble,"TOOA-PI1") # Crea un'istanza della "Peripheral" BLE personalizzata
idx_status = 0 # Per il simulatore dello stato della macchina

# Formatta i dati RX/TX BLE in un formato esadecimale facilmente leggibile per il debug
def pkt_format (data: bytes):
    pkt = data.hex().upper()
    f_pkt = '|'
    for i in range(int(len(pkt)/2)):
        f_pkt = f_pkt + pkt[2*i:2*i+2] + '|'
    return f_pkt

# Questa funzione viene eseguita ogni volta che un "Central" scrive la caratteristica RX della "Peripheral"
# cioè ogni volta che riceviamo un pacchetto di dati
def on_rx(v):
    global idx_status
    
    print("RX :", pkt_format(v))

    # Status Response simulator
    s = [b'\xAA\x00\x01\x01\x82\x00\x25\x00\x00\x00\x00\x00\x00\x00\x01\x22\x01\x05\x01\x00\x00\x49\x02\x13\x2F\x5B\x00\x49\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x30\x30\x30\x00\x00\x00',
         b'\xAA\x00\x01\x01\x82\x00\x25\x00\x00\x00\x00\x00\x00\x00\x01\x2C\x01\x05\x01\x00\x00\x49\x02\x13\x2F\x6E\x00\x49\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x30\x30\x30\x00\x00\x00',
         b'\xAA\x00\x01\x01\x82\x00\x25\x00\x00\x00\x00\x00\x00\x00\x01\x2C\x01\x05\x01\x00\x00\x49\x02\x13\x2F\x6E\x00\x49\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x30\x30\x30\x00\x00\x00',
         b'\xAA\x00\x01\x01\x82\x00\x25\x00\x00\x00\x00\x00\x00\x00\x01\x2C\x01\x05\x01\x00\x00\x49\x02\x13\x2F\x6E\x00\x49\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x30\x30\x30\x00\x00\x00']

    if p.is_connected():
        data = s[idx_status] + mb.CRC16(s[idx_status]) 
        # print("TX", data)
        print('TX :', pkt_format(data))
        p.send(data)
        if idx_status < len(s)-1:
            idx_status += 1
        else:
            idx_status = 0
# Assegna la specifica funzione di callback che viene eseguita quando un "Central" scrive la caratteristica RX della "Peripheral"
p.on_write(on_rx)  
# Bluetooth communication ########################################################### END

# OTA Update check: questa procedura aggiorna un solo script python, es. test.py
R, G, B, blink = (0, 255, 0, True) # Lampeggio durante l'aggiornamento del firmware
firmware_url = "https://github.com/Marce68/Pi-Pico-GEM/"
ota_updater = OTAUpdater(SSID, PASSWORD, firmware_url, "test.py")
ota_updater.download_and_install_update_if_available()

print ("STATUS\t\tI_MOT\t\tT_CAV\t\tV_MOT\t\tT_MCU\t\tPOS_SW\t\tSELECT")
debug.write("STATUS\t\tI_MOT\t\tT_CAV\t\tV_MOT\t\tT_MCU\t\tPOS_SW\t\tSELECT\n")

# Ritardo necessario pe il test in linea della macchina (misura del consumo in Stand-by)
power_on_time = time.ticks_ms() # Accensione macchina
power_on_elapsed_time = 0
stand_by = False




# Main Loop #########################################################################
while True:
    
    power_on_elapsed_time = time.ticks_diff(time.ticks_ms(),power_on_time)  

    if current_status == status['Idle'] and POS_SW.value() == 1: # IDLE + braccio motore sollevato
        R, G, B, blink = (150, 245, 0, False) # Giallo/verde fisso
        if power_on_elapsed_time > 10000: # Accensione pompa e ventole dopo 10 secondi dall'accensione macchina
            C_PUMP_FAN.duty_u16(int(255 * 65535 / 255))
    elif current_status == status['Idle']: # Transizione Idle --> Ready per iniziare il conteggio dello stand by
        current_status = status['Ready']
        ready_init_time = time.ticks_ms()
    elif POS_SW.value() == 1: # In ogni stato della macchina se il braccio è alzato il colore è il giallo/verde
        R, G, B, blink = (150, 245, 0, False)
    elif current_status == status['Ready']:
        R, G, B, blink = (0, 201, 204, False) # Ciano fisso
        C_PUMP_FAN.duty_u16(int(255 * 65535 / 255))
        ready_elapsed_time = time.ticks_diff(time.ticks_ms(), ready_init_time)
        print(ready_elapsed_time, " - ", stand_by, end = "\r") # debug......
        if ready_elapsed_time >= 60000: # Dopo 1 minuti in 'Ready' senza alcuna interazione (xTest, portortare a 5 min)
            stand_by = True
            standByCycle()
    elif current_status == status['Run_std'] and cycle_duration > 0:
        R, G, B, blink = (0, 201, 204, True) # Ciano lampeggiante
        runCycle()
    elif current_status == status['Pause']:
        R, G, B, blink = (255, 255, 255, True)
    else:
         R, G, B, blink = (255, 0, 0, True)
    
    time.sleep(0.5) # Necessario per gestire correttamente gli interrupts e le relative callback
