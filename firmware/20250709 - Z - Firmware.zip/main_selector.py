from machine import Pin, PWM, UART, Timer
from time import sleep
import time

import BLEXpress_Peripheral

# PIN definition and settings ##################################################################
BUILTIN_LED = Pin('LED', Pin.OUT)
START = Pin('GPIO15', Pin.IN)
POS_SW = Pin('GPIO11',Pin.IN)

C_TEC_POW = Pin('GPIO21',Pin.OUT)

LED_R = PWM(Pin('GPIO14'))
LED_G = PWM(Pin('GPIO13'))
LED_B = PWM(Pin('GPIO12'))
LED_R.freq(1000)
LED_G.freq(1000)
LED_B.freq(1000)

C_BUZ = PWM(Pin('GPIO7'))
C_BUZ.freq(4000)

C_MOT = PWM(Pin('GPIO2'))
C_MOT.freq(20000)

C_PUMP_FAN = PWM(Pin('GPIO8'))
C_PUMP_FAN.freq(20000)

I_MOT = machine.ADC(26) # ADC0
T_CAV = machine.ADC(27) # ADC1
V_MOT = machine.ADC(28) # ADC2
T_MCU = machine.ADC(4) # Internal temperature sensor
MAX_SAMPLES = 30
I_MOT_BUFF = []
T_CAV_BUFF = []
V_MOT_BUFF = []
T_MCU_BUFF = []


# Debug UART #################################################################################
debug = UART(0, baudrate=9600, tx=Pin('GPIO0'), rx=Pin('GPIO1'))
debug.init(bits=8, parity=None, stop=1)

# Variabili globali ##########################################################################
dbg_str = ""
# debounce_timer = None
start_time = 0
pulse_duration = 0
selector = 0

# SYSTEM_STATUS
# 0x00 == 0 == Blocked
# 0x01 == 1 == Ready for Production
# 0x02 == 2 == Production (std time)
# 0x12 == 18 == Production (ext time)
# 0x03 == 3 == Production finished (std time)
# 0x13 == 19 == Production finished (ext time)
# 0x04 == 4 == Production interrupted
# 0x05 == 5 == Error
# 0xFF == 255 == Idle
status = {
    'Idle' : 0xFF,
    'Blocked' : 0x00,
    'Ready' : 0x01,
    'Run_std' : 0x02,
    'Run_ext' : 0x18,
    'End_std' : 0x03,
    'End_ext' : 0x19,
    'Pause' : 0x04,
    'Error' : 0x05
}
current_status = status['Idle']

# Function and Callbacks ##########################################################################
def setColor(R, G, B):
    # Set the duty cycle for each color channel
    LED_R.duty_u16(int(R * 65535 / 255))
    LED_G.duty_u16(int(G * 65535 / 255))
    LED_B.duty_u16(int(B * 65535 / 255))

def dumpData ():
    global current_status, selector
    
    dbg_str = str('{x:6d}'.format(x=current_status) +
    '\t\t{x:5.2f}'.format(x=sum(I_MOT_BUFF)/MAX_SAMPLES) +
    '\t\t{x:5.2f}'.format(x=sum(T_CAV_BUFF)/MAX_SAMPLES) +
    '\t{x:5.2f}'.format(x=sum(V_MOT_BUFF)/MAX_SAMPLES) +
    '\t\t{x:5.2f}'.format(x=sum(T_MCU_BUFF)/MAX_SAMPLES) +              
    '\t\t{x:6d}'.format(x=POS_SW.value()) +
    '\t\t{x:6d}'.format(x=selector) + '\n\r')
    
#     dbg_str = str("STATUS = " + str(current_status) +
#                   "\t I_MOT = " + str(sum(I_MOT_BUFF)/MAX_SAMPLES) +
#                   "\t T_CAV = " + str(sum(T_CAV_BUFF)/MAX_SAMPLES) +
#                   "\t V_MOT = " + str(sum(V_MOT_BUFF)/MAX_SAMPLES) +
#                   "\t T_MCU = " + str(sum(T_MCU_BUFF)/MAX_SAMPLES) +
#                   "\t POS_SW = " + str(POS_SW.value()) + "\n\r")
    print(dbg_str, end ='\r')
    debug.write(dbg_str)

# def debounce_callback(timer):
#     global debounce_timer
#     debounce_timer = None
# 
# def startPressed(pin):
#     global debounce_timer, current_status
#     
#     if debounce_timer == None:
#         # Example only to switch sequentially over all possible statuses
#         if current_status == status['Idle']:
#             current_status = status['Blocked']
#         elif current_status == status['Blocked']:
#             current_status = status['Ready']
#         elif current_status == status['Ready']:
#             current_status = status['Run_std']
#         elif current_status == status['Run_std']:
#             current_status = status['Run_ext']
#         elif current_status == status['Run_ext']:
#             current_status = status['End_std']
#         elif current_status == status['End_std']:
#             current_status = status['End_ext']
#         elif current_status == status['End_ext']:
#             current_status = status['Pause']
#         elif current_status == status['Pause']:
#             current_status = status['Error']
#         elif current_status == status['Error']:
#             current_status = status['Idle']
#         else:
#             current_status = 0xAA
#         
#         dumpData()
#         
#         debounce_timer = Timer()
#         debounce_timer.init(mode=Timer.ONE_SHOT, period=200, callback=debounce_callback)

def START_irq_handler(pin):
    global start_time, pulse_duration, current_status, selector
    if pin.value() == 0:
        # Fronte di discesa: inizio impulso
        start_time = time.ticks_us()
    else:
        # Fronte di salita: fine impulso
        end_time = time.ticks_us()
        pulse_duration = time.ticks_diff(end_time, start_time)
        # print("Durata impulso:", pulse_duration, "us")
        
        # Selector position
        if pulse_duration > 1500 and pulse_duration < 2000:
            selector = 1
        elif pulse_duration > 3500 and pulse_duration < 4000:
            selector = 2
        elif pulse_duration > 5500 and pulse_duration < 6000:
            selector = 3
        elif pulse_duration > 7500 and pulse_duration < 8000:
            selector = 4
        elif pulse_duration > 9500 and pulse_duration < 10000:
            selector = 5
        elif pulse_duration > 11500 and pulse_duration < 12000:
            selector = 6
        elif pulse_duration > 13500 and pulse_duration < 14000:
            selector = 7
        elif pulse_duration > 15500 and pulse_duration < 16000:
            selector = 8
        
        # Start pressed ?
        if pulse_duration > 2500 and pulse_duration < 3000:
            # Example only to switch sequentially over all possible statuses
            if current_status == status['Idle']:
                current_status = status['Blocked']
            elif current_status == status['Blocked']:
                current_status = status['Ready']
            elif current_status == status['Ready']:
                current_status = status['Run_std']
            elif current_status == status['Run_std']:
                current_status = status['Run_ext']
            elif current_status == status['Run_ext']:
                current_status = status['End_std']
            elif current_status == status['End_std']:
                current_status = status['End_ext']
            elif current_status == status['End_ext']:
                current_status = status['Pause']
            elif current_status == status['Pause']:
                current_status = status['Error']
            elif current_status == status['Error']:
                current_status = status['Idle']
            else:
                current_status = 0xAA
            dumpData()
        
def adcGetSamples (timer):
    I_MOT_BUFF.append(I_MOT.read_u16())
    T_CAV_BUFF.append(T_CAV.read_u16())
    V_MOT_BUFF.append(V_MOT.read_u16())
    T_MCU_BUFF.append(27-(T_MCU.read_u16()*(3.3/65536)-0.706)/0.001721)

    if len (I_MOT_BUFF) > MAX_SAMPLES:
        I_MOT_BUFF.pop(0)
        T_CAV_BUFF.pop(0)
        V_MOT_BUFF.pop(0)
        T_MCU_BUFF.pop(0)

def toggle_led(timer):
    BUILTIN_LED.value(not BUILTIN_LED.value())  # Toggle the LED state (ON/OFF)
    
def runCycle1 ():
    #setColor(0, 201, 204)
    setColor(255, 0, 0)
    C_MOT.duty_u16(int(128 * 65535 / 255))
    C_TEC_POW.value(1)
    sleep(1)  # Wait for 1 second
    
    # Set RGB color to soft red
    #setColor(247, 120, 138)
    setColor(0, 255, 0)
    C_BUZ.duty_u16(int(0 * 65535 / 255))
    C_PUMP_FAN.duty_u16(int(128 * 65535 / 255))
    sleep(1)  # Wait for 1 second

def runCycle2 ():
    # Set RGB color to green
    #setColor(52, 168, 83)
    setColor(0, 0, 255)
    C_MOT.duty_u16(int(191 * 65535 / 255))
    C_TEC_POW.value(0)
    sleep(1)  # Wait for 1 second
    
    setColor(255, 255, 255)
    C_BUZ.duty_u16(int(128 * 65535 / 255))
    C_PUMP_FAN.duty_u16(int(0 * 65535 / 255))
    sleep(1)  # Wait for 1 second

# Interrupts
# START.irq(trigger=Pin.IRQ_RISING, handler=startPressed)
START.irq(trigger=Pin.IRQ_RISING | Pin.IRQ_FALLING, handler=START_irq_handler)

# Timers
blink_timer = Timer()
blink_timer.init(mode=Timer.PERIODIC, period=500, callback=toggle_led)

adc_timer = Timer()
adc_timer.init(mode=Timer.PERIODIC, period=100, callback=adcGetSamples)

print ("STATUS\t\tI_MOT\t\tT_CAV\t\tV_MOT\t\tT_MCU\t\tPOS_SW\t\tSELECT")
debug.write("STATUS\t\tI_MOT\t\tT_CAV\t\tV_MOT\t\tT_MCU\t\tPOS_SW\t\tSELECT")

while True:
    # dumpData()
    # if flavour == 'cream':
    if current_status == status['Ready']:
        BLEXpress_Peripheral.demo ()
    if current_status == status['Run_std']:
        runCycle1 ()
    else:
        runCycle2 ()

      


  