"""
Implementazione di un dispositivo BLE periferico con servizio Xpress Streaming
e Device Information Service.

Servizi implementati:
- Xpress Streaming: comunicazione bidirezionale tra dispositivo e client
  - TX: Invio dati dal dispositivo al client (notifiche)
  - RX: Ricezione dati dal client al dispositivo (scrittura)
  - MODE: Caratteristica per configurazione/controllo
- Device Information Service (0x180A): informazioni sul dispositivo
"""

import bluetooth
import time
from ble_advertising import advertising_payload
from micropython import const


# ============================================================================
# COSTANTI - Eventi IRQ (Interrupt Request) BLE
# ============================================================================

# Un dispositivo centrale (client) si è connesso
_IRQ_CENTRAL_CONNECT = const(1)

# Un dispositivo centrale (client) si è disconnesso
_IRQ_CENTRAL_DISCONNECT = const(2)

# Il client ha scritto dati su una caratteristica GATT
_IRQ_GATTS_WRITE = const(3)


# ============================================================================
# COSTANTI - Flag per caratteristiche GATT
# ============================================================================

# La caratteristica può essere letta
_FLAG_READ = const(0x0002)

# La caratteristica può essere scritta senza risposta (più veloce)
_FLAG_WRITE_NO_RESPONSE = const(0x0004)

# La caratteristica può essere scritta con risposta di conferma
_FLAG_WRITE = const(0x0008)

# La caratteristica supporta notifiche (push dal server)
_FLAG_NOTIFY = const(0x0010)

# La caratteristica supporta indicazioni (notifiche con ACK)
_FLAG_INDICATE = const(0x0020)


# ============================================================================
# DEFINIZIONE SERVIZIO XPRESS STREAMING
# ============================================================================

# UUID principale del servizio Xpress
_XPRESS_UUID = bluetooth.UUID("331a36f5-2459-45ea-9d95-6142f0c4b307")

# Caratteristica TX: per inviare dati dal dispositivo al client
# Supporta notifiche e indicazioni
_XPRESS_TX = (
    bluetooth.UUID("a73e9a10-628f-4494-a099-12efaf72258f"),
    _FLAG_NOTIFY | _FLAG_INDICATE,
)

# Caratteristica RX: per ricevere dati dal client
# Supporta scrittura con e senza risposta
_XPRESS_RX = (
    bluetooth.UUID("a9da6040-0823-4995-94ec-9ce41ca28833"),
    _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE,
)

# Caratteristica MODE: per controllo/configurazione
# Supporta lettura, scrittura e notifiche
_XPRESS_MODE = (
    bluetooth.UUID("75a9f022-af03-4e41-b4bc-9de90a47d50b"),
    _FLAG_READ | _FLAG_WRITE | _FLAG_WRITE_NO_RESPONSE | _FLAG_NOTIFY | _FLAG_INDICATE,
)

# Definizione completa del servizio con tutte le sue caratteristiche
_XPRESS_SERVICE = (
    _XPRESS_UUID,
    (_XPRESS_RX, _XPRESS_TX, _XPRESS_MODE),
)


# ============================================================================
# DEFINIZIONE DEVICE INFORMATION SERVICE (0x180A)
# ============================================================================

# UUID del Device Information Service
_DIS_UUID = bluetooth.UUID(0x180A)

# UUID delle caratteristiche del DIS (tutte in sola lettura)
_DIS_MANUFACTURER = (
    bluetooth.UUID(0x2A29),  # Manufacturer Name String
    _FLAG_READ,
)

_DIS_MODEL_NUMBER = (
    bluetooth.UUID(0x2A24),  # Model Number String
    _FLAG_READ,
)

_DIS_SERIAL_NUMBER = (
    bluetooth.UUID(0x2A25),  # Serial Number String
    _FLAG_READ,
)

_DIS_HARDWARE_REVISION = (
    bluetooth.UUID(0x2A27),  # Hardware Revision String
    _FLAG_READ,
)

_DIS_FIRMWARE_REVISION = (
    bluetooth.UUID(0x2A26),  # Firmware Revision String
    _FLAG_READ,
)

_DIS_SOFTWARE_REVISION = (
    bluetooth.UUID(0x2A28),  # Software Revision String
    _FLAG_READ,
)

# Definizione completa del Device Information Service
_DIS_SERVICE = (
    _DIS_UUID,
    (
        _DIS_MANUFACTURER,
        _DIS_MODEL_NUMBER,
        _DIS_SERIAL_NUMBER,
        _DIS_HARDWARE_REVISION,
        _DIS_FIRMWARE_REVISION,
        _DIS_SOFTWARE_REVISION,
    ),
)


# ============================================================================
# CLASSE PRINCIPALE - Periferico BLE Semplice
# ============================================================================

class BLESimplePeripheral:
    """
    Gestisce un dispositivo BLE periferico con servizio Xpress Streaming
    e Device Information Service.
    
    Funzionalità:
    - Advertising automatico per essere scoperto
    - Gestione connessioni multiple
    - Invio dati tramite notifiche
    - Ricezione dati con callback personalizzabile
    - Informazioni sul dispositivo accessibili via BLE
    """
    
    def __init__(self, ble, name="TOOA-pi", device_info=None):
        """
        Inizializza il periferico BLE.
        
        Parametri:
            ble: Oggetto bluetooth.BLE()
            name: Nome del dispositivo mostrato durante lo scan (default: "TOOA-pi")
            device_info: Dizionario con informazioni sul dispositivo (opzionale)
                        Chiavi supportate:
                        - 'manufacturer': Nome produttore
                        - 'model': Numero modello
                        - 'serial': Numero seriale
                        - 'hardware': Revisione hardware
                        - 'firmware': Revisione firmware
                        - 'software': Revisione software
        """
        self._ble = ble
        self._ble.active(True)
        
        # Registra il gestore degli eventi BLE
        self._ble.irq(self._irq)
        
        # Registra entrambi i servizi (Xpress e Device Information)
        (
            (self._handle_manufacturer, self._handle_model, self._handle_serial,
             self._handle_hardware, self._handle_firmware, self._handle_software),
            (self._handle_rx, self._handle_tx, self._handle_mode),
        ) = self._ble.gatts_register_services((_DIS_SERVICE, _XPRESS_SERVICE))
        
        # Imposta le informazioni del dispositivo
        if device_info is None:
            device_info = {}
        
        self._set_device_info(
            manufacturer=device_info.get('manufacturer', 'TooA SpA'),
            model=device_info.get('model', 'PicoW-Stream-v2'),
            serial=device_info.get('serial', 'SN-2025-01'),
            hardware=device_info.get('hardware', 'GEM-r2-PicoW-RP2040'),
            firmware=device_info.get('firmware', 'uPython v1.26.0'),
            software=device_info.get('software', 'GEM_0.3.5-beta'),
        )
      
        # Set per tracciare tutte le connessioni attive
        self._connections = set()
        
        # Callback da chiamare quando arrivano dati su RX
        self._write_callback = None
        
        # Crea il payload di advertising con nome e UUID di entrambi i servizi
#         self._payload = advertising_payload(
#             name=name, 
#             services=[_XPRESS_UUID, _DIS_UUID]
#         )
        # Crea il payload di advertising con nome e UUID di entrambi i servizi
        # IMPORTANTE: Il nome deve essere passato come bytes
        print('Bluetooth name:', name)
        self._payload = advertising_payload(
            name=name, 
            services=[_XPRESS_UUID]
        )
        
        # Avvia l'advertising
        self._advertise()
        
        # Aumenta il buffer della caratteristica RX a 250 bytes
        # Il terzo parametro (True) abilita append automatico
        self._ble.gatts_set_buffer(self._handle_rx, 250, True)
    
    def _set_device_info(self, manufacturer, model, serial, hardware, firmware, software):
        """
        Imposta i valori del Device Information Service.
        
        Parametri:
            manufacturer: Nome del produttore
            model: Numero del modello
            serial: Numero seriale
            hardware: Revisione hardware
            firmware: Revisione firmware
            software: Revisione software
        """
        self._ble.gatts_write(self._handle_manufacturer, manufacturer.encode())
        self._ble.gatts_write(self._handle_model, model.encode())
        self._ble.gatts_write(self._handle_serial, serial.encode())
        self._ble.gatts_write(self._handle_hardware, hardware.encode())
        self._ble.gatts_write(self._handle_firmware, firmware.encode())
        self._ble.gatts_write(self._handle_software, software.encode())
    
    def _irq(self, event, data):
        """
        Gestore degli eventi BLE (callback interna).
        
        Parametri:
            event: Tipo di evento (es: connessione, disconnessione, scrittura)
            data: Dati associati all'evento
        """
        # EVENTO: Un client si è connesso
        if event == _IRQ_CENTRAL_CONNECT:
            conn_handle, _, _ = data
            print(f"Nuova connessione: handle {conn_handle}")
            self._connections.add(conn_handle)
            
            # Continua l'advertising per permettere altre connessioni
            # Intervallo: 500ms (500000 microsecondi)
            self._ble.gap_advertise(interval_us=500000, adv_data=self._payload)
        
        # EVENTO: Un client si è disconnesso
        elif event == _IRQ_CENTRAL_DISCONNECT:
            conn_handle, _, _ = data
            print(f"Disconnessione: handle {conn_handle}")
            self._connections.remove(conn_handle)
            
            # Riavvia l'advertising per permettere nuove connessioni
            self._advertise()
        
        # EVENTO: Un client ha scritto su una caratteristica
        elif event == _IRQ_GATTS_WRITE:
            conn_handle, value_handle = data
            
            # Leggi il valore scritto
            value = self._ble.gatts_read(value_handle)
            
            # Se è stata scritta la caratteristica RX e c'è un callback, chiamalo
            if value_handle == self._handle_rx and self._write_callback:
                self._write_callback(value)
    
    def send(self, data):
        """
        Invia dati a tutti i client connessi tramite notifiche.
        
        Parametri:
            data: Dati da inviare (bytes o string)
        """
        for conn_handle in self._connections:
            self._ble.gatts_notify(conn_handle, self._handle_tx, data)
    
    def is_connected(self):
        """
        Verifica se ci sono client connessi.
        
        Ritorna:
            bool: True se almeno un client è connesso, False altrimenti
        """
        return len(self._connections) > 0
    
    def _advertise(self, interval_us=500000):
        """
        Avvia l'advertising BLE per rendere il dispositivo scopribile.
        
        Parametri:
            interval_us: Intervallo di advertising in microsecondi (default: 500ms)
        """
        print("Advertising avviato")
        self._ble.gap_advertise(interval_us, adv_data=self._payload)
    
    def on_write(self, callback):
        """
        Registra una funzione callback da chiamare quando arrivano dati.
        
        Parametri:
            callback: Funzione da chiamare con firma callback(data)
                     dove data è di tipo bytes
        
        Esempio:
            def on_rx(data):
                print("Ricevuto:", data)
            
            peripheral.on_write(on_rx)
        """
        self._write_callback = callback


# ============================================================================
# DEMO - Esempio di utilizzo
# ============================================================================

def demo():
    """
    Funzione dimostrativa che mostra come usare il periferico BLE.
    
    Funzionamento:
    - Crea un periferico BLE con informazioni sul dispositivo
    - Registra un callback per stampare i dati ricevuti
    - Invia dati incrementali ogni secondo quando un client è connesso
    """
    print("=== Demo BLE Xpress Streaming + Device Information ===\n")
    
    # Inizializza il Bluetooth
    ble = bluetooth.BLE()
    
    # Definisci le informazioni sul dispositivo
    device_info = {
        'manufacturer': 'TOOA SpA',
        'model': 'PicoW-Stream-v2',
        'serial': 'SN-2025-11',
        'hardware': 'GEM-r2-PicoW-RP2040',
        'firmware': 'MicroPython v1.26.0',
        'software': 'GEM_0.3.5-beta',
    }
    
    # Crea il periferico con le informazioni del dispositivo
    peripheral = BLESimplePeripheral(ble, name="TOOA-pi", device_info=device_info)
    
    print("Servizi attivi:")
    print("  - Xpress Streaming Service")
    print("  - Device Information Service (0x180A)")
    print()
    
    # Definisci il callback per i dati ricevuti
    def on_rx(value):
        """Chiamata quando il client scrive sulla caratteristica RX"""
        print(f"← Ricevuto: {value}")
    
    # Registra il callback
    peripheral.on_write(on_rx)
    
    # Contatore per i messaggi
    counter = 0
    
    # Loop principale
    while True:
        if peripheral.is_connected():
            # Invia una raffica di 3 notifiche
            for _ in range(3):
                data = f"{counter}_"
                print(f"→ Invio: {data}")
                peripheral.send(data.encode())
                counter += 1
        else:
            print("In attesa di connessione...")
        
        # Attendi 1 secondo prima del prossimo invio
        time.sleep_ms(1000)


if __name__ == "__main__":
    demo()