"""
Helper per generare e decodificare payload di advertising BLE.

I payload di advertising sono pacchetti ripetuti con la seguente struttura:
  - 1 byte: lunghezza dei dati (N + 1)
  - 1 byte: tipo di dato (vedi costanti sotto)
  - N bytes: dati specifici per quel tipo
"""

from micropython import const
import struct
import bluetooth


# ============================================================================
# COSTANTI - Tipi di dati per advertising BLE
# ============================================================================

# Flag che indicano le capacità del dispositivo
_ADV_TYPE_FLAGS = const(0x01)

# Nome completo del dispositivo
_ADV_TYPE_NAME = const(0x09)

# UUID dei servizi - Lista completa (16 bit)
_ADV_TYPE_UUID16_COMPLETE = const(0x03)

# UUID dei servizi - Lista completa (32 bit)
_ADV_TYPE_UUID32_COMPLETE = const(0x05)

# UUID dei servizi - Lista completa (128 bit)
_ADV_TYPE_UUID128_COMPLETE = const(0x07)

# UUID dei servizi - Lista parziale (16 bit)
_ADV_TYPE_UUID16_MORE = const(0x02)

# UUID dei servizi - Lista parziale (32 bit)
_ADV_TYPE_UUID32_MORE = const(0x04)

# UUID dei servizi - Lista parziale (128 bit)
_ADV_TYPE_UUID128_MORE = const(0x06)

# Aspetto del dispositivo (icona da mostrare)
_ADV_TYPE_APPEARANCE = const(0x19)


# ============================================================================
# FUNZIONE PRINCIPALE - Genera payload di advertising
# ============================================================================

def advertising_payload(limited_disc=False, br_edr=False, name=None, 
                       services=None, appearance=0):
    """
    Genera un payload BLE da passare a gap_advertise(adv_data=...).
    
    Parametri:
        limited_disc (bool): Se True, usa Limited Discoverable Mode (default: False)
        br_edr (bool): Se True, supporta BR/EDR (Bluetooth Classic) (default: False)
        name (str): Nome del dispositivo da mostrare nello scan
        services (list): Lista di UUID dei servizi BLE disponibili
        appearance (int): Codice appearance secondo spec Bluetooth
                         (es: 0x03C0 = Generic Phone)
    
    Ritorna:
        bytearray: Payload formattato per advertising BLE
    """
    payload = bytearray()
    
    # Funzione interna per aggiungere campi al payload
    def _append(adv_type, value):
        nonlocal payload
        # Formato: [lunghezza][tipo][dati...]
        payload += struct.pack("BB", len(value) + 1, adv_type) + value
    
    # 1. Aggiungi i flag del dispositivo
    # Bit 0-1: Discoverable mode (0x01=Limited, 0x02=General)
    # Bit 2: BR/EDR not supported (0x04)
    # Bit 3-4: BR/EDR controller/host (0x18 se supportato)
    flag_value = (0x01 if limited_disc else 0x02) + (0x18 if br_edr else 0x04)
    _append(_ADV_TYPE_FLAGS, struct.pack("B", flag_value))
    
    # 2. Aggiungi il nome del dispositivo (se fornito)
    if name:
        _append(_ADV_TYPE_NAME, name.encode() if isinstance(name, str) else name)
    
    # 3. Aggiungi gli UUID dei servizi (se forniti)
    if services:
        for uuid in services:
            # Converte l'UUID in bytes
            b = bytes(uuid)
            
            # Scegli il tipo corretto in base alla lunghezza dell'UUID
            if len(b) == 2:
                # UUID a 16 bit (es: 0x180A = Device Information)
                _append(_ADV_TYPE_UUID16_COMPLETE, b)
            elif len(b) == 4:
                # UUID a 32 bit (raro)
                _append(_ADV_TYPE_UUID32_COMPLETE, b)
            elif len(b) == 16:
                # UUID a 128 bit (servizi custom)
                _append(_ADV_TYPE_UUID128_COMPLETE, b)
    
    # 4. Aggiungi l'appearance (se specificato)
    # Vedi: org.bluetooth.characteristic.gap.appearance.xml
    if appearance:
        _append(_ADV_TYPE_APPEARANCE, struct.pack("<h", appearance))
    
    return payload


# ============================================================================
# FUNZIONI DI DECODIFICA - Estrae informazioni dal payload
# ============================================================================

def decode_field(payload, adv_type):
    """
    Estrae tutti i campi di un determinato tipo dal payload.
    
    Parametri:
        payload (bytes): Payload BLE da decodificare
        adv_type (int): Tipo di campo da cercare (es: _ADV_TYPE_NAME)
    
    Ritorna:
        list: Lista di valori trovati per quel tipo
    """
    i = 0
    result = []
    
    # Scorri tutto il payload
    while i + 1 < len(payload):
        length = payload[i]  # Lunghezza del campo corrente
        field_type = payload[i + 1]  # Tipo del campo corrente
        
        # Se il tipo corrisponde, estrai i dati
        if field_type == adv_type:
            data_start = i + 2
            data_end = i + length + 1
            result.append(payload[data_start:data_end])
        
        # Passa al campo successivo
        i += 1 + length
    
    return result


def decode_name(payload):
    """
    Estrae il nome del dispositivo dal payload.
    
    Parametri:
        payload (bytes): Payload BLE da decodificare
    
    Ritorna:
        str: Nome del dispositivo, o stringa vuota se non trovato
    """
    names = decode_field(payload, _ADV_TYPE_NAME)
    return str(names[0], "utf-8") if names else ""


def decode_services(payload):
    """
    Estrae la lista di servizi BLE dal payload.
    
    Parametri:
        payload (bytes): Payload BLE da decodificare
    
    Ritorna:
        list: Lista di oggetti bluetooth.UUID dei servizi trovati
    """
    services = []
    
    # Estrai UUID a 16 bit
    for uuid_bytes in decode_field(payload, _ADV_TYPE_UUID16_COMPLETE):
        uuid_value = struct.unpack("<H", uuid_bytes)[0]  # Little-endian unsigned short
        services.append(bluetooth.UUID(uuid_value))
    
    # Estrai UUID a 32 bit
    for uuid_bytes in decode_field(payload, _ADV_TYPE_UUID32_COMPLETE):
        uuid_value = struct.unpack("<I", uuid_bytes)[0]  # Little-endian unsigned int
        services.append(bluetooth.UUID(uuid_value))
    
    # Estrai UUID a 128 bit
    for uuid_bytes in decode_field(payload, _ADV_TYPE_UUID128_COMPLETE):
        services.append(bluetooth.UUID(uuid_bytes))
    
    return services


# ============================================================================
# DEMO - Esempio di utilizzo
# ============================================================================

def demo():
    """
    Funzione dimostrativa che crea un payload e lo decodifica.
    """
    print("=== Demo Helper BLE Advertising ===\n")
    
    # Crea un payload con nome e servizi
    payload = advertising_payload(
        name="micropython",
        services=[
            bluetooth.UUID(0x181A),  # Environmental Sensing (16-bit)
            bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")  # Custom (128-bit)
        ],
    )
    
    print("Payload generato (hex):")
    print(" ".join(f"{b:02x}" for b in payload))
    print()
    
    # Decodifica il payload
    print(f"Nome decodificato: {decode_name(payload)}")
    print(f"Servizi decodificati: {decode_services(payload)}")


if __name__ == "__main__":
    demo()