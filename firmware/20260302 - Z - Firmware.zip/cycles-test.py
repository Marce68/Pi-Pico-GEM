import json

with open("cycles-test.json", "r") as f:
    c = json.load(f)
    
