# *** Modifiche ***
# - Aggiunta la disattivazione del wifi alla fine della funzione "download_and_install_update_if_available"
# La funzione "connect_wifi" ha ora un'attesa massima di circa 10 secondi e ritorna un valore True o False
# - Aggiunta la funzione "set_time" per aggiornare l'orologio interno (RTC) all'ora di Greenwich (GMT)
# - Download di file multipli (ota.py, la "m" sta per multipli) --> gestisce il download di una lista di files
# scritta nel file config.json - OK
# - La funzione "download_and_install_update_if_available" che aggiorna il firmware fa anche l'upload del
# contenuto di cycle.json ad ogni avvio e lo resetta.


# *** Note ***
# 1. Se per il collegamento internet si usa un mobile hotspot, attivare e configurare l'hotspot dopo aver spento
# il WiFi perchè questo modo il telefono deve mostrare tutte le opzioni come la scelta della "Band AP" 2.4/5.0 GHz
# è necessario selezionare la banda 2.4 GHz

import network
import urequests
import os
import json
import machine
# from time import sleep
import time
import ntptime
import socket
import struct
import gc

# import ujson

sta_if = None

SHEETS_URL = 'https://script.google.com/macros/s/AKfycbzBm0dTTV5lmhWB97tlkvOfgpO-7cN1MU_rlX8wCjQPEmflf6gLThDT6yIseKVvxX4_/exec'


class OTAUpdater:
    """ This class handles OTA updates. It connects to the Wi-Fi, checks for updates, downloads and installs them."""

    def __init__(self, ssid, password, repo_url, filenames):
        self.filenames = filenames
        self.ssid = ssid
        self.password = password
        self.repo_url = repo_url
        
        self.version_url = self.repo_url + 'version.json'
        print(f"version url is: {self.version_url}")
        
        self.firmware_url = []
        for i in range(len(self.filenames)):
            self.firmware_url.append(self.repo_url + self.filenames[i])

        # get the current version (stored in the local version.json)
        if 'version.json' in os.listdir():    
            with open('version.json') as f:
                self.current_version = int(json.load(f)['version'])
            print(f"Current device firmware version is '{self.current_version}'")
        else:
            self.current_version = 0 # if version.json does not exists save the current version as 0
            with open('version.json', 'w') as f:
                json.dump({'version': self.current_version}, f)


    def connect_wifi(self):
        """ Connect to Wi-Fi."""
        global sta_if
        
        sta_if = network.WLAN(network.STA_IF)
        sta_if.active(True) # WiFi *ON*
        sta_if.connect(self.ssid, self.password)
        count = 0
        while not sta_if.isconnected():
            print('.', end="")
            count += 1
            time.sleep(0.25)
            if count > 40:
                print('Connection timeout')
                return False
        else:
            print(f'Connected to WiFi, IP is: {sta_if.ifconfig()[0]}')
            self.set_time() # Imposta RTC interno
            return True


    def fetch_latest_code(self, i)->bool:
        """ Fetch the latest code from the repo, returns False if not found."""
        is_ok = False
        
        # Free RAM beforehand as much as possible
        gc.collect()
        
        # Print free RAM before loading file
        print(f"Free RAM before file fetching: {gc.mem_free()} bytes")
        
        # Fetch the latest code from the repo.
        response = urequests.get(self.firmware_url[i])
        if response.status_code == 200:
            print(f'Fetched latest firmware code, status: {response.status_code}')
    
            # Save the fetched code to memory
            self.latest_code = response.text
            is_ok = True
        
        elif response.status_code == 404:
            print(f'Firmware not found - {self.firmware_url[i]}.')
        
        response.close()
        del response
        gc.collect()
        
        return result

    def update_no_reset(self, i):
        """ Update the code without resetting the device."""

        # Save in flash the fetched code and assign it the name as defined in config.json
        with open('latest_code.tmp', 'w') as f:
            f.write(self.latest_code)
        
        # free up some memory
        self.latest_code = None
        
        # Overwrite the old code.
        os.rename('latest_code.tmp', self.filenames[i])

        # Print free RAM after loading file
        print(f"Free RAM after file fetching: {gc.mem_free()} bytes")


    def update_and_reset(self):
        """ Update the version number and reset the device."""
        
        print(f"Updating device firmware version ... ", end="")
        
        # update the version in memory
        self.current_version = self.latest_version
        # save the current version
        with open('version.json', 'w') as f:
            json.dump({'version': self.current_version}, f)

        # Restart the device to run the new code.
        print('Restarting device...')
        machine.reset()  # Reset the device to run the new code.


    def check_for_updates(self):
        """ Check if updates are available."""
        
        # Connect to Wi-Fi
        if not self.connect_wifi():
            return False

        print(f'Checking for latest version... on {self.version_url}')
        response = urequests.get(self.version_url)
        data = json.loads(response.text)
        response.close()
        
        self.latest_version = int(data['version'])
        print(f'Latest firmware version is: {self.latest_version}')
        
        # compare versions
        newer_version_available = True if self.current_version < self.latest_version else False
        
        print(f'Newer version available: {newer_version_available}')    
        return newer_version_available


    def download_and_install_update_if_available(self):
        """ Check for updates, download and install them."""
        
        # compare version numbers
        if self.check_for_updates():
            # check the full set of files listed in config.json
            for i in range(len(self.firmware_url)):
                # update only the files available at the url repo
                if self.fetch_latest_code(i):
                    self.update_no_reset(i)            
            # update version numbers and reset the machine
            self.update_and_reset()

        else:
            print('No new updates available.')
                
        # Carico il file dei cicli ...
        with open('cycles.json', 'r') as f:
            c = json.load(f)
            
        # ... e lo invio ad un foglio Google Sheets
        gc.collect()   # liberiamo un po' di memoria in maniera preventiva
        for k in c:
            if k != "next":
                # Trasformazione data e ora in un formato leggibile per Google Sheets
                # lavoro su una copia del ciclo corrente, in caso di errore salvo senza alterare il formato
                temp_c = json.loads(json.dumps(c[k]))      
                anno, mese, giorno, ora, minuto, secondo, _, _ = temp_c["start_time"]
                time_string = "{:02d}/{:02d}/{} {:02d}.{:02d}.{:02d}".format(giorno, mese, anno, ora, minuto, secondo)
                temp_c["start_time"] = time_string
                temp_c["status"] = str(temp_c["status"])
                print(temp_c, end="")
                
                response = None
                time.sleep_ms(1)         
                try:
                    # Prepare data before the request to minimize time the socket is open
                    payload = json.dumps(temp_c)
                    
                    # Perform the POST
                    response = urequests.post(
                        SHEETS_URL,
                        headers = {'Content-Type': 'application/json'},
                        data = payload,
                        timeout = 10
                    )
                    
                    if response is not None:
                        # Using status_code is safer than just checking the text ...
                        #
                        # ... ma non funziona perchè response è sempre 400 (Bad Request)
                        # anche se il post viene eseguito correttamente
                        #
                        res_status = response.status_code
                        res_text = response.text
                        response.close()   # 1. Close the response
                        response = None    # 2. Reset the object
                        gc.collect()       # 3. Clean up memory
                        
                        
                        # if 200 <= response.status_code < 300:
                        if True:
                            if "OK" in res_text:
                                print(".", k, ".", res_status, ".")
                            else:
                                print("|", k, "|", res_status, "|")
                            # Cancello dal dizionario il dato inviato con successo
                            c.pop(k)
                        else:
                            print(f"Error {response.status_code}")
                            print(f"Text: {response.text}")
                    else:
                        print('No response from Google Sheets')
                    
                    time.sleep(0.5)

                except Exception as e:
                    print('Errore OTA-GSheet1:', e)
                    # Ensure we still collect garbage
                    if response is not None:
                        response.close()
                        del response
                        gc.collect()
                    time.sleep(3.0)
        
        # Reset del file dei cicli solo se è stato completamente svuotato
        if len(c) == 1:
            c["next"] = 1
            
        # Riscrivo il file dei cicli da cui sono stati eliminati quelli inviati a Google Sheets
        with open("cycles.json", "w") as f:
            f.write(json.dumps(c))
                    
#                 try:
#                     response = urequests.post(
#                         SHEETS_URL,
#                         headers = {'Content-Type': 'application/json'},
#                         data = json.dumps(c[str(i)])
#                     )
#                     
#                     gc.collect()  # ogni richiesta (socket TCP) richiede molta memoria
#                     # print('Risposta:', response.text)
#                     if response != None:
#                         res = response.text
#                         response.close()
#                         if "OK" in res:
#                             print(i, '.', end="")
#                         else:
#                             print(i, "|", end="")
#                         # Cancello il dato inviato con successo
#                         c.pop(str(i))
#                     else:
#                         print('Nessuna risposta da Google Sheets !!!')
#                     time.sleep(0.5)
#                 except Exception as e:
#                     print('Errore OTA-GSheet1:', e)
#                     time.sleep(3.0)
# !!!! Così non va bene perchè "i" dopo il ciclo for non è definita ...
#         try:
#             print(i)
#             if i == len(c)-1:
#                 with open("cycles.json", "w") as f:
#                      f.write(json.dumps({"next": 1}))
#         except Exception as e:
#             print('Errore OTA-OTA-GSheet2:', e)
            
        # *****************************

        # WiFi *OFF*
        sta_if.active(False)


    def set_time(self):
        """ Update internal RTC """

        try:
            ntptime.settime()
            print("NTP Time: ", time.localtime())
        except:
            print("Errore nella sincronizzazione NTP")
        
